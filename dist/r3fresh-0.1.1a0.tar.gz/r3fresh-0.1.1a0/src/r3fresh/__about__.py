# SPDX-FileCopyrightText: 2026-present r3fresh
#
# SPDX-License-Identifier: MIT
__version__ = "0.1.1-alpha"